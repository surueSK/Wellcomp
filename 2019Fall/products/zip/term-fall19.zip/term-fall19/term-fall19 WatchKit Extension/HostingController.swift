//
//  HostingController.swift
//  term-fall19 WatchKit Extension
//
//  Created by 助川友理 on 2020/01/09.
//  Copyright © 2020 助川友理. All rights reserved.
//

import WatchKit
import Foundation
import SwiftUI

class HostingController: WKHostingController<ContentView> {
    override var body: ContentView {
        return ContentView()
    }
}
