//
//  NotificationView.swift
//  term-fall19 WatchKit Extension
//
//  Created by 助川友理 on 2020/01/09.
//  Copyright © 2020 助川友理. All rights reserved.
//

import SwiftUI

struct NotificationView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct NotificationView_Previews: PreviewProvider {
    static var previews: some View {
        NotificationView()
    }
}
