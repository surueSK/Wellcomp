//
//  ToDoItemView.swift
//  2019fterm
//
//  Created by 助川友理 on 2020/01/04.
//  Copyright © 2020 助川友理. All rights reserved.
//

import SwiftUI
import Alamofire

struct ToDoItemView: View {
   @Environment(\.managedObjectContext) var managedObjectContext
    var title:String = ""
    var createdAt:String = ""
    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(title)
                .font(.headline)
                Text(createdAt)
                .font(.caption)
            }
            Text("1")
            Button(action: {
                let toDoItem = ToDoItem(context: self.managedObjectContext)
                gettime()
                toDoItem.tasktime = Date()
                AF.request("http://martini.ht.sfc.keio.ac.jp/~lindt/CountLaunchPost.php",method: .post,parameters: )
            }){
                Text("START")
            }
        }
    }
}


//時間取得機能
let formatter = DateFormatter()
weak var timer:Timer!
var startTime = Date()
func gettime(){
    formatter.timeStyle = .full
    formatter.dateStyle = .full
    let now = Date()
    print(formatter.string(from: now))
}

class TodoPost:Codable{
    @NSManaged public var createdAt: Date?
    @NSManaged public var title:String?
     @NSManaged public var tasktime:Date?
}

#if DEBUG
struct ToDoItemView_Previews: PreviewProvider {
    static var previews: some View {
        ToDoItemView()
    }
}
#endif
